angular.module('TurkishApp')
	.constant('config',{
		"serverUrl" : 'http://localhost:3131/'
	});